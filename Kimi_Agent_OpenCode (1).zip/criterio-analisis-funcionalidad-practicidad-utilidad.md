# Criterio de Análisis: Funcionalidad, Practicidad y Utilidad
### Marco de evaluación para apps de operación de campo (aplicado a "Promesa de Pago Digital")

Este criterio sirve para dos cosas: **decidir qué entra y qué no entra** en una app de este tipo, y **evaluar si lo que ya está construido realmente le sirve al usuario de campo y al cliente que la compra**. Úsalo como checklist cada que DeepSeek, otro modelo o un cliente proponga una mejora.

---

## 1. Las tres dimensiones

### A. FUNCIONALIDAD — ¿Hace lo que promete, completo y sin fallos?
| # | Pregunta de prueba | Puntos |
|---|---|---|
| F1 | ¿La función ejecuta su tarea de punta a punta, sin pasos rotos ni mensajes muertos? | 0-2 |
| F2 | ¿Funciona sin señal o con señal mala (la realidad del gestor en la calle)? | 0-2 |
| F3 | ¿Los datos no se pierden: sobreviven a recarga, cierre de app y cambio de pantalla? | 0-2 |
| F4 | ¿Los errores humanos comunes (tecleo, campos vacíos, fecha equivocada) tienen salida fácil? | 0-2 |
| F5 | ¿Se integra con lo que ya existe sin romper nada? | 0-2 |

### B. PRACTICIDAD — ¿Cabe en la operación real, tal como es hoy?
| # | Pregunta de prueba | Puntos |
|---|---|---|
| P1 | ¿Un gestor de 40-55 años, con celular gama baja y sol de frente, la puede usar sin capacitación? | 0-2 |
| P2 | ¿Ahorra pasos respecto a como lo hace hoy (papel, WhatsApp suelto, Excel nocturno)? Cuenta los toques. | 0-2 |
| P3 | ¿Usa las palabras que el gestor ya usa (promesa, abono, quincena) o le exige aprender términos nuevos? | 0-2 |
| P4 | ¿Interrumpe o exige cambiar el proceso actual? (Entre menos, mejor: Continuidad Aumentada) | 0-2 |
| P5 | ¿Funciona en el tiempo real que tiene el gestor: 30 segundos junto a la puerta del deudor? | 0-2 |

### C. UTILIDAD — ¿Cambia una decisión o ahorra tiempo/dinero medible?
| # | Pregunta de prueba | Puntos |
|---|---|---|
| U1 | ¿Al gestor le resuelve algo de HOY (qué cobrar, a quién llamar, qué sigue)? | 0-2 |
| U2 | ¿Al supervisor le quita trabajo real (doble captura, reporte nocturno, perseguir datos)? | 0-2 |
| U3 | ¿Al directivo le muestra algo que antes no podía ver (embudo del día, certeza de cobro)? | 0-2 |
| U4 | ¿El beneficio se puede presumir en la demo en menos de 60 segundos? | 0-2 |
| U5 | ¿El beneficio sobrevive al día 30 de uso, o es solo vistoso el primer día? | 0-2 |

**Lectura del puntaje (máximo 30):**
- **24-30** → Entra a la app ya. Es de las que venden la demo.
- **17-23** → Entra solo si es barato de construir y no ensucia la pantalla.
- **10-16** → Déjalo anotado para la versión comercial, no para el piloto.
- **0-9** → No entra. Es adorno o es negocio de otra app.

**Regla de veto (sin importar puntaje):** se rechaza de inmediato cualquier función que (a) exija backend o costo mensual en el piloto, (b) rompa el offline-first, (c) agregue un paso obligatorio a la captura de 30 segundos, o (d) use datos reales sensibles de personas.

---

## 2. Evaluación aplicada a las mejoras de esta versión

| Mejora | Func. | Pract. | Util. | Total | Decisión |
|---|---|---|---|---|---|
| Pestaña "Por Cobrar Hoy" con semáforo de atraso | 10 | 10 | 10 | **30** | Entró — es la operación real del día 2 en adelante |
| Botones WhatsApp / Llamar en la tarjeta | 9 | 10 | 10 | **29** | Entró — un toque reemplaza 2 minutos de tecleo |
| Foto del comprobante (compresión en el teléfono) | 9 | 8 | 10 | **27** | Entró — la prueba reina en cobranza de campo |
| Resumen WhatsApp para el supervisor | 10 | 10 | 9 | **29** | Entró — los mandos medios leen WhatsApp, no PDFs |
| Edición de promesa capturada | 10 | 9 | 8 | **27** | Entró — el error humano de tecleo es diario |
| Alta de usuarios en vivo | 9 | 8 | 9 | **26** | Entró — convierte una pregunta del director en momento de venta |
| Chips de resumen del gestor ("por cobrar hoy $X") *(aportación Kimi)* | 9 | 9 | 9 | **27** | Entró — el gestor abre la app y sabe cuánto debe traer hoy |
| TCE blindada contra altas nuevas *(aportación Kimi)* | 8 | 8 | 7 | **23** | Entró — evita que una demo con nuevo gestor muestre un % imposible |

## 3. Lo que el criterio RECHAZÓ (y por qué sigue fuera)

| Propuesta | Por qué no entra al piloto |
|---|---|
| Geofencing / GPS | Veto (a): agita a los gestores ("me van a espiar") y rompe la filosofía de no-disrupción |
| OCR de comprobantes | Veto (b): exige servidor y conexión; la foto comprimida ya resuelve la evidencia |
| Scoring predictivo con IA | U5 bajo: sin historial real de 6+ meses, cualquier "score" es teatro |
| Integración SPEI / WhatsApp API | Veto (a): costo y backend; el botón wa.me ya da el 90% del valor |
| Multi-empresa | U3 no aplica: el piloto vende a UNA financiera a la vez |
| Filtros y gráficas avanzadas | P1: el supervisor de hoy quiere tabla + Excel, no un BI |

---

## 4. Cómo usarlo en tus próximas apps (barbería, seguros, taxis)

1. Antes de aceptar cualquier mejora (de DeepSeek, del cliente o mía), pásala por las 15 preguntas.
2. Si dos funciones empatan en puntaje, gana la que se pueda **demostrar en vivo en menos de 60 segundos**.
3. Re-evalúa la app completa cada 2 semanas de uso real: lo que puntúa alto y nadie toca, se quita; lo que todos piden y puntúa bajo, se re-diseña, no se niega.
4. El criterio no mide qué tan bonita es la app; mide si el gestor la seguirá usando el día 30.
