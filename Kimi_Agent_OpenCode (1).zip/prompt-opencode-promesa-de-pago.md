# PROMPT MAESTRO PARA OPENCODE
## App: "Promesa de Pago Digital" — MVP Demostrable v1.0-piloto

Copia TODO el contenido de abajo de esta línea y pégalo como un solo mensaje en OpenCode:

---

## ROL Y OBJETIVO

Actúa como un desarrollador senior full-stack especializado en PWAs offline-first. Vas a construir una aplicación web progresiva (PWA) funcional, de un solo módulo, que digitaliza ÚNICAMENTE la captura de promesas de pago en cobranza de campo en México.

**Contexto de uso:** Será presentada como demo en vivo (5 a 8 minutos) ante 3 a 6 ejecutivos de una financiera/SOFOM mexicana. NO requiere backend productivo ni infraestructura compleja. Todo corre local en el navegador.

**Filosofía rectora:** "Continuidad Aumentada, No Disrupción". La app NO reemplaza el proceso del gestor de cobranza; lo complementa con una capa invisible de captura y visibilidad en tiempo real.

**Criterio de éxito de la demo:** Un ejecutivo debe poder decir al final: "Esto no interrumpe nada de lo que ya hacemos, y por primera vez veríamos el embudo de promesas antes del cierre del día".

**Prioridad absoluta:** Simplicidad radical sobre completitud. Es mejor una app de 3 pantallas que funcione perfectamente offline y exporte un Excel real, que una app de 10 pantallas a medio funcionar. Código limpio, comentado en español.

---

## STACK TÉCNICO OBLIGATORIO

- **Vanilla HTML/CSS/JS puro, CERO build, CERO framework.** No uses React, Vue, ni npm para la app en sí.
- **Única dependencia externa:** SheetJS (xlsx) desde CDN para la exportación a Excel: `https://cdn.sheetjs.com/xlsx-0.20.3/package/dist/xlsx.full.min.js`
- **Estado local:** IndexedDB con un wrapper propio simple (promisificado, sin librerías). LocalStorage solo como fallback de configuración.
- **PWA completa:** `manifest.webmanifest` + `sw.js` (service worker con cache-first de los assets estáticos). La app debe ser instalable en móvil.
- **Iconografía:** Emojis discretos o SVG inline minimalista. Sin librerías de íconos externas.
- **Sin backend, sin autenticación real:** Login simulado con selector de rol.
- **Idioma de UI:** Español de México, tono cercano y directo, sin tecnicismos.

**Estructura de archivos a generar:**

```
promesa-de-pago/
├── index.html          # App completa (login + vista gestor + vista supervisor en una sola página con routing por hash o vistas ocultas)
├── styles.css          # Estilos con paleta corporativa
├── app.js              # Lógica de UI, vistas y eventos
├── db.js               # Wrapper de IndexedDB (promesas, gestores)
├── seed.js             # Datos de ejemplo precargados
├── export.js           # Exportación a Excel con SheetJS
├── sw.js               # Service worker (cache-first)
├── manifest.webmanifest
├── icon-192.png        # Icono simple: checkmark sobre documento (puede ser SVG convertido o placeholder generado)
├── icon-512.png
└── README.md           # Instrucciones de ejecución y despliegue
```

**Paleta corporativa sobria:**
- Azul marino principal: `#0F2A43`
- Gris neutro: `#6B7280` / fondos `#F3F4F6`
- Blanco: `#FFFFFF`
- Verde de confirmación: `#16A34A`
- Rojo discreto para incumplidas: `#DC2626`
- Ámbar para pendientes: `#D97706`

---

## ROLES Y VISTAS

### 1. Login simulado (pantalla inicial)
- Sin password. Dos tarjetas grandes seleccionables: **"Soy Gestor"** y **"Soy Supervisor"**.
- Al elegir Gestor, mostrar un selector con los 3 gestores precargados para "entrar como" ese gestor.
- Botón o enlace visible para cambiar de rol en cualquier momento (importante para la demo).

### 2. Vista Gestor (mobile-first, es lo único que usa el gestor de campo)

**Componente A — Formulario "Nueva Promesa de Pago":**

Campos obligatorios (máximo 4 visibles, 1 pantalla, 1 botón):
| Campo | Tipo | Detalle |
|---|---|---|
| `nombre_deudor` | text | Placeholder "Nombre del cliente", max 80 caracteres |
| `monto_prometido` | number | Máscara numérica MXN, solo números, placeholder "$ 0.00", validación: mayor a 0 |
| `fecha_pago` | date | Selector de calendario nativo, NO texto libre |
| `canal_contacto` | select | Opciones: WhatsApp, Llamada, SMS, Visita domiciliaria, Otro |

Campos opcionales (colapsados o secundarios):
- `notas`: textarea, placeholder "Observaciones (opcional)", max 200 caracteres.
- `foto_comprobante`: botón secundario GRIS, deshabilitado visualmente con etiqueta "Próximamente" (es fase futura, solo mostrar el concepto).

**Botón principal:** "Guardar Promesa".

**Feedback de éxito:** Toast verde con el texto exacto: **"Promesa guardada. Se enviará al recuperar señal."**

**Comportamiento offline:** Guardar en IndexedDB con flag `sync_pending: true`. La promesa aparece inmediatamente en la lista con badge "pendiente de enviar".

**Componente B — Lista "Mis Promesas de Hoy":**
- Lista simple, sin filtros avanzados. Cada tarjeta muestra: nombre del deudor, monto (formato MXN), fecha de pago, canal, estado (capturada / cumplida / incumplida) y badge de sincronización.
- Acciones por tarjeta: "Marcar cumplida", "Marcar incumplida", "Ver detalle" (modal con todos los datos).
- Colores de estado: verde = cumplida, rojo = incumplida, ámbar = capturada/pendiente.

### 3. Vista Supervisor (desktop-optimized, es lo que ven los ejecutivos)

**Componente A — "Embudo de Promesas del Día" (tarjetas KPI + gráfico de barras simple en CSS/SVG puro, sin librerías de gráficos):**
| KPI | Formato | Meta visual |
|---|---|---|
| Promesas capturadas hoy | Entero | — |
| Monto total prometido | Moneda MXN | — |
| Tasa de Captura Efectiva (TCE) | % — fórmula: (promesas_registradas / gestiones_con_acuerdo) × 100 | Mostrar meta ">85%" |
| Índice de Certeza de Cumplimiento (ICC) | % — fórmula: (monto_cobrado_promesas / monto_total_promesas) × 100 | — |

Para la TCE, simula `gestiones_con_acuerdo` como dato seed (número fijo por gestor).

**Componente B — Tabla "Detalle de Promesas por Gestor":**
- Columnas: Gestor, Deudor, Monto, Fecha compromiso, Canal, Estado, Días de atraso.
- Orden por fecha de compromiso ascendente.
- Búsqueda simple (input que filtra por nombre de deudor o gestor).

**Componente C — Botón "Exportar Reporte de Cierre":**
- Genera y descarga un archivo `.xlsx` REAL con SheetJS.
- Hoja llamada "Promesas" con columnas: Gestor, Zona, Deudor, Monto Prometido, Fecha Compromiso, Canal, Estado, Fecha de Captura.
- Nombre de archivo: `reporte_promesas_YYYY-MM-DD.xlsx`.
- Este es el punto crítico de la demo: elimina el doble reporte. El gestor captura una vez, el supervisor exporta y firma.

**Componente D — Indicador de sincronización:**
- Badge visible que muestra cuántas promesas están "pendientes de enviar" (para que el supervisor sepa qué falta por llegar).
- Badge global de conexión (online/offline) usando `navigator.onLine` y eventos `online`/`offline`. Texto en lenguaje simple: "Con señal" / "Sin señal — trabajando sin conexión".
- Cuando vuelve la conexión, simular el envío: después de 2 segundos, cambiar `sync_pending` a `false` y actualizar badges con un toast "Promesas enviadas al recuperar señal".

---

## DATOS PRECARGADOS (SEED)

La app debe arrancar con datos de ejemplo realistas para que la demo fluya sin capturar todo en vivo. Al primer arranque, si IndexedDB está vacío, insertar el seed. Agregar en el login un enlace discreto "Restablecer datos de demo" que limpia la base y vuelve a sembrar.

**Gestores:**
```json
[
  { "id": "g1", "nombre": "Laura Méndez", "zona": "Iztapalapa Norte" },
  { "id": "g2", "nombre": "Carlos Ramírez", "zona": "Tlalnepantla Centro" },
  { "id": "g3", "nombre": "José Antonio Torres", "zona": "Guadalajara Sur" }
]
```

**Promesas:** Mínimo 15, distribuidas entre los 3 gestores:
- 8 cumplidas, 3 incumplidas, 4 capturadas (pendientes).
- Montos entre $500 y $25,000 MXN.
- Fechas de compromiso entre hoy y los próximos 15 días (calcular dinámicamente contra la fecha actual, NO fechas fijas).
- Nombres de deudores mexicanos comunes y ficticios (María López, Juan Hernández, Guadalupe Torres, Pedro Sánchez, etc.). NUNCA datos reales.
- Las cumplidas deben tener `monto_cobrado` (para que el ICC salga realista, cobra alrededor del 65-70% del monto total prometido).
- Algunas promesas con fecha de compromiso ya vencida y estado "capturada" para que la columna "Días de atraso" muestre valores reales.

---

## REGLAS UX OBLIGATORIAS

1. **Lenguaje familiar del gestor:** usar "promesa", "abono", "quincena", "fin de mes", "cliente". PROHIBIDO: "scoring", "geofencing", "lead", "pipeline", "sincronizar", "cache", "API". Si hay que mencionar la sincronización, decir "guardado local, se enviará al recuperar señal".
2. **Flujo mínimo:** formulario de promesa = máximo 4 campos visibles, 1 pantalla, 1 botón de guardar.
3. **Confirmación visible:** cada acción tiene feedback claro (toast, cambio de color, animación breve de máximo 300ms).
4. **Tono visual:** sobrio, corporativo, sin ilustraciones caricaturescas. Sensación de herramienta de trabajo, no de app de consumo.
5. **Accesibilidad:** contraste adecuado, botones táctiles mínimo 44×44px, fuentes legibles en exterior (mínimo 16px en formularios móviles).
6. **Offline-first estricto:** TODA la app funciona sin conexión. El service worker cachea todo en la primera carga. La "sincronización" es simulada localmente.
7. **Persistencia:** los datos sobreviven a recarga de página (IndexedDB).
8. **Tiempo de carga:** menor a 2 segundos en 3G simulado (verificar con throttling de DevTools).

---

## FUERA DE ALCANCE — NO IMPLEMENTAR

- NO geofencing ni GPS.
- NO OCR ni procesamiento de imágenes.
- NO IA ni scoring predictivo.
- NO ruteo ni mapas.
- NO autenticación real con passwords.
- NO integración con WhatsApp, SPEI ni core bancario.
- NO multi-tenant ni multi-empresa.
- NO backend ni base de datos externa.

---

## CHECKLIST DE ACEPTACIÓN (verifica todo antes de entregar)

1. [ ] La app abre con `python3 -m http.server` o `npx serve` sin errores de consola.
2. [ ] Login con selector de rol funciona y permite cambiar de rol.
3. [ ] El gestor guarda una promesa y aparece de inmediato en "Mis Promesas de Hoy" con badge "pendiente de enviar".
4. [ ] Al activar modo offline en DevTools, la app sigue funcionando completa y muestra el badge "Sin señal".
5. [ ] Al volver online, las promesas pendientes cambian a enviadas automáticamente con toast.
6. [ ] El supervisor ve la promesa recién capturada reflejada en el embudo y la tabla sin recargar (o con un cambio de vista).
7. [ ] El botón "Exportar Reporte de Cierre" descarga un `.xlsx` real que abre en Excel/LibreOffice con la hoja "Promesas" y los datos correctos.
8. [ ] La app es instalable como PWA (manifest + service worker válidos, verificar en DevTools > Application).
9. [ ] Los datos sobreviven a recarga de página.
10. [ ] "Restablecer datos de demo" limpia y re-siembra la base.
11. [ ] Vista gestor se ve bien en viewport móvil (375×667) y vista supervisor en escritorio (1440×900).
12. [ ] Cero palabras técnicas en la UI (revisar que no aparezca "sincronizar", "cache", "API", "offline" en inglés).

---

## README.md QUE DEBES GENERAR

Incluir:
1. Cómo ejecutar localmente (dos opciones: `python3 -m http.server 8080` o `npx serve`).
2. Por qué no funciona con doble clic al archivo (los service workers requieren HTTP) — explicado en una frase simple.
3. Cómo desplegar gratis: Netlify Drop (arrastrar la carpeta a app.netlify.com/drop) o Vercel.
4. Guion de demo sugerido (7 pasos): login → captura en vivo → lista con badge → cambio a supervisor → embudo actualizado → tabla → exportar Excel → cierre con indicador de señal.

---

## ORDEN DE TRABAJO SUGERIDO

1. Crea la estructura de archivos y el `db.js` (wrapper IndexedDB) primero.
2. Luego `seed.js` con los datos de ejemplo.
3. Luego `index.html` + `styles.css` con las tres vistas (login, gestor, supervisor).
4. Luego `app.js` con la lógica de navegación, formulario, lista, tabla y KPIs.
5. Luego `export.js` (SheetJS).
6. Al final `sw.js` + `manifest.webmanifest` y verificación PWA.
7. Ejecuta el checklist de aceptación completo y corrige lo que falle antes de decir que terminaste.

Genera la aplicación completa y funcional ahora.
